import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Formik, Field, Form } from 'formik';
// import BasicFormSchema from '../components/BasicFormSchema';


import { fetchPerson } from '../redux/actions/person';

function Suport() {
    const dispatch = useDispatch();

    const items = useSelector(({ person }) => person.items);
    const isLoaded = useSelector(({ person }) => person.isLoaded);

  
    React.useEffect(() => {
      dispatch(fetchPerson());
    }, []);

    console.log(items, isLoaded)

    // baseHandler = (event) =>{
    //     this.setState({sample: {...this.state.sample, base: event.target.value}})
    //   }
    
    //   base2Handler = (event) =>{
    //     this.setState({sample: {...this.state.sample, base2: event.target.value}})
    //   }
    
    //   sampleDateHandler = (event) =>{
    //     this.setState({sample: {...this.state.sample, date: event.target.value}})
    //   }
    
    //   dataWrite = async () =>{
    
    //     await fetch(`https://api.exchangeratesapi.io/${this.state.sample.date}?base=${this.state.sample.base}`)
    //     .then((response)=> response.json()).then((response)=>{
    //       this.setState({sample: {...this.state.sample, course: response.rates[this.state.sample.base2]}})
    //     })
    
    //     await axios.post('https://rateapp-832c2.firebaseio.com/sample.json', this.state.sample)
    //     .then((response)=> {
    //       return('')
    //     })
    
    //     await axios('https://rateapp-832c2.firebaseio.com/sample.json')
    //     .then((response)=>{
    //       this.setState({sampleList: response.data})
    //     })
    //   }

    return (
        <div className="suport">
            {/* <div className="container">
                <h1>Cauta utilizator</h1>
                <Formik
                initialValues={{
                    phone: "",
                    idnp: "",
                    date: ""
                }}
                validationSchema={BasicFormSchema}
                onSubmit={values => {
                    setTimeout(() => {
                    alert(JSON.stringify(values, null, 2));
                    }, 500);
                }}
                render={({ errors, touched }) => (
                    <Form className="form-container">

                    <label htmlFor="idnp">IDNP</label>
                    <Field name="idnp" placeholder="snapoak" type="text" />

                    {errors.idnp &&
                        touched.idnp && (
                        <div className="field-error">{errors.idnp}</div>
                        )}

                    <label htmlFor="phone">Nr.Telefon</label>
                    <Field
                        name="phone"
                        placeholder="mtarasov777@gmail.com"
                        type="phone"
                    />

                    {errors.phone &&
                        touched.phone && <div className="field-error">{errors.phone}</div>}

                    <label htmlFor="date">Data Acces</label>
                    <Field name="date" type="date" />

                    {errors.date &&
                        touched.date && (
                        <div className="field-error">{errors.date}</div>
                        )}

                    <button type="submit">CAUTA</button>
                    </Form>
                )}
                />
            </div> */}
            <div className="content-title">
                <h3>Suport</h3>
            </div>
            <div className="suport__form">
                <div className="support__title">
                    <h4>Cauta utilizator</h4>
                </div>
                <Formik
                    initialValues={{
                        phone: "",
                        idnp: "",
                        date: ""
                    }}
                    //   validate={values => {
                    //     const errors = {};
                    //     if (!values.email) {
                    //       errors.email = 'Required';
                    //     } else if (
                    //       !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                    //     ) {
                    //       errors.email = 'Invalid email address';
                    //     }
                    //     return errors;
                    //   }}
                    onSubmit={(values, { setSubmitting }) => {
                        setTimeout(() => {
                        alert(JSON.stringify(values, null, 2));
                        setSubmitting(false);
                        }, 400);
                    }}>

                    {({ isSubmitting }) => (

                    <Form>

                        <label htmlFor="idnp">IDNP</label>
                        <Field name="idnp" placeholder="" type="text" />
                        {/* <ErrorMessage name="idnp" component="div" /> */}

                        <label htmlFor="phone">Nr.Telefon</label>
                        <Field
                            name="phone"
                            placeholder=""
                            type="phone"
                        />
                        {/* <ErrorMessage name="phone" component="div" /> */}

                        <label htmlFor="date">Data Acces</label>
                        <Field name="date" type="date" />
                        {/* <ErrorMessage name="date" component="div" /> */}


                    <button type="submit" disabled={isSubmitting}>CAUTA</button>

                    </Form>

                    )}

                </Formik>
            </div>
            {/* <form className="suport__form">
                <div className="support__title">
                    <h4>Cauta utilizator</h4>
                </div>
                <div className="suport__form-item">
                    <label htmlFor="idnp">
                        IDNP
                    </label>
                    <input id="idnp" type="number" />
                </div>
                <div className="suport__form-item">
                    <label htmlFor="phone">
                        Nr.Telefon
                    </label>
                    <input id="phone" type="number" />
                </div>
                <div className="suport__form-item">
                    <label htmlFor="date">
                        Data Acces
                    </label>
                    <input id="date" type="date" />
                </div>
                <div className="suport__form-item">
                    <button>CAUTA</button>
                </div>
            </form> */}
            <div className="suport__rezult">
                <div className="support__title">
                    <h4>Rezultale cautare:</h4>
                    <h4> Joe Doe</h4>
                </div>
                <table className="table suport__rezult-main">
                    <thead>
                        <tr>
                        <th scope="col">Nume Prenume</th>
                        <th scope="col">IDNP</th>
                        <th scope="col">Nr.Telefon</th>
                        <th scope="col">PAN Card</th>
                        <th scope="col">Last transaction</th>
                        </tr>
                    </thead>
                    <tbody>
                    {isLoaded ? items.map((item, key)=>{
                        return(
                            <tr key={key}>
                                <th scope="row">{item.name}</th>
                                <td>{item.idnp}</td>
                                <td>{item.phone}</td>
                                <td>{item.card}</td>
                                <td>{item.date}</td>
                            </tr>
                        )})
                    : null }
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default Suport;





///// 
// import React from "react";
// import { Formik, Field, Form } from "formik";
// import BasicFormSchema from "./BasicFormSсhema";

// const SignUp = () => (
//   <div className="container">
//     <h1>Cauta utilizator</h1>
//     <Formik
//       initialValues={{
//         phone: "",
//         idnp: "",
//         date: ""
//       }}
//       validationSchema={BasicFormSchema}
//       onSubmit={values => {
//         setTimeout(() => {
//           alert(JSON.stringify(values, null, 2));
//         }, 500);
//       }}
//       render={({ errors, touched }) => (
//         <Form className="form-container">

//           <label htmlFor="idnp">IDNP</label>
//           <Field name="idnp" placeholder="snapoak" type="text" />

//           {errors.idnp &&
//             touched.idnp && (
//               <div className="field-error">{errors.idnp}</div>
//             )}

//           <label htmlFor="phone">Nr.Telefon</label>
//           <Field
//             name="phone"
//             placeholder="mtarasov777@gmail.com"
//             type="phone"
//           />

//           {errors.phone &&
//             touched.phone && <div className="field-error">{errors.phone}</div>}

//           <label htmlFor="date">Data Acces</label>
//           <Field name="date" type="date" />

//           {errors.date &&
//             touched.date && (
//               <div className="field-error">{errors.date}</div>
//             )}

//           <button type="submit">CAUTA</button>
//         </Form>
//       )}
//     />
//   </div>
// );

// export default SignUp;
